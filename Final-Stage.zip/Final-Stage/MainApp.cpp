/** 
 *  @file    MainApp.cpp
 *  @author  (zmaroofz) Zagros Maroofzadeh
 *  @date    28/11/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 final stage group project assignment1, starts the application and creates the interface as well as the functionality for put,post,and getting information from the emulator
 *		user can create,edit,select,grab all, and remove bridges. once a bridge is select you can view/edit/grab lights from that bridge or created a group
 *		a scheduler can also be created from this information
 */
#include <Wt/WApplication>
#include <Wt/WContainerWidget>
#include <Wt/WServer>
#include <thread>
#include <chrono>
#include <Wt/Http/Client>
#include <Wt/Auth/AuthModel>
#include <Wt/Auth/AuthWidget>
#include <Wt/Auth/PasswordService>
#include <Wt/WLineEdit>
#include <Wt/WPushButton>
#include <string>
#include <Wt/Dbo/collection>
#include <Wt/WIOService>
#include <time.h>
#include "AuthWidget.h"
#include "Bridge.h"
#include "Group.h"
#include "model/Session.h"

using namespace Wt;
class HueApplication : public Wt::WApplication{
public:

  /** 
  *   @brief  Constructor for the main Application
  *  
  *   @param  Wt::WApplication is wt environment
  *   @return void
  */ 

HueApplication(const Wt::WEnvironment& env): Wt::WApplication(env),session_(appRoot() + "auth.db"){
	session_.login().changed().connect(this, &HueApplication::authEvent);
	useStyleSheet("css/style.css");
	messageResourceBundle().use("strings");
	messageResourceBundle().use("templates");

	AuthWidget *authWidget = new AuthWidget(session_);//create the auth widget

	authWidget->model()->addPasswordAuth(&Session::passwordAuth());//set authwidget settings
	authWidget->model()->addOAuth(Session::oAuth());
	authWidget->setRegistrationEnabled(true);

	authWidget->processEnvironment();

	root()->addWidget(authWidget);//add auth widget to screen
}


  /** 
  *   @brief  Controls the user login/logout and initializes the creation of the interface   
  *   @return void
  */ 

void authEvent() {
	if (session_.login().loggedIn()) {//user succesfully logged in
		Wt::log("notice") << "User " << session_.login().user().id()<< " logged in.";
		Wt::Dbo::Transaction t(session_);
		dbo::ptr<User> user = session_.user();
		createButtons();//create the interface for editing hue lights
	} 
	else{
		Wt::log("notice") << "User logged out.";
		root()->clear();//clear the page
		AuthWidget *authWidget = new AuthWidget(session_);//then re-add the main control settings
		authWidget->model()->addPasswordAuth(&Session::passwordAuth());
		authWidget->model()->addOAuth(Session::oAuth());
		authWidget->setRegistrationEnabled(true);
		authWidget->processEnvironment();
		root()->addWidget(authWidget);
	}
}
	
  /** 
  *   @brief  Creates the interface (text,input, and buttons) for all functions excluding the logout button
  *   @return void
  */ 
void createButtons(){

	root()->addWidget(new WText("Enter Bridge Name"));  // show some text
	nameEdit_ = new WLineEdit(root());                     // allow text input
	nameEdit_->setFocus(); 
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("Enter Bridge Ip"));  // show some text
	ipEdit_ = new WLineEdit(root()); 
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("Enter Bridge Location"));  // show some text
	locationEdit_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("Enter Bridge Port"));  // show some text
	portEdit_ = new WLineEdit(root());
	root()->addWidget(new WText("<br />"));  

	root()->addWidget(new WText("Enter UserName (optional)"));  // show some text
	usernameEdit_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));



	WPushButton *button = new WPushButton("Create Bridge", root());              // create a button for creating bridges
	button->clicked().connect(this, &HueApplication::createBridge);
	response_ = new WText(root()); 
  
  
	WPushButton *buttongetBRi = new WPushButton("Get all bridges", root());              // create a button for displaying bridges
	buttongetBRi->clicked().connect(this, &HueApplication::displayBridges);
  
  	root()->addWidget(new WText("Select bridge by id: "));  // show some text
	bridgeIDSelect_ = new WLineEdit(root());  
      
	WPushButton *deleteBridge = new WPushButton("Delete bridge", root());              // create a button for deleting a bridge
	deleteBridge->clicked().connect(this, &HueApplication::deleteBridge);


	WPushButton *editBridge = new WPushButton("Edit bridge", root());              // create a button for editing a bridge
	editBridge->clicked().connect(this, &HueApplication::editBridge);	
	
	WPushButton *selectBridge = new WPushButton("Select bridge", root());              // create a button for selecting a bridge
	selectBridge->clicked().connect(this, &HueApplication::selectBridge);


	root()->addWidget(new WText("<br />light num"));  // show some text
	lightNum_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("light/group state (on/off)"));  // show some text
	lightState_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));



	root()->addWidget(new WText("light/group brightness(1-254)"));  // show some text
	bri_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));


	root()->addWidget(new WText("light/group hue(0-65535)"));  // show some text
	hue_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));


	root()->addWidget(new WText("light/group transition time (>0)"));  // show some text
	transitiontime_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("change light name"));  // show some text
	ligtName_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));


	WPushButton *buttonLight = new WPushButton("Change Light", root());              // create a button for editing a light
	buttonLight->clicked().connect(this, &HueApplication::changeLightVariables);
  
	WPushButton *buttonLight2 = new WPushButton("Get all lights", root());              // create a button for getting all lights
	buttonLight2->clicked().connect(this, &HueApplication::getAllLights);

	WPushButton *buttonLight3 = new WPushButton("Get specific light", root());              // create a button for getting a light
	buttonLight3->clicked().connect(this, &HueApplication::getLight);    

  
  
 	root()->addWidget(new WText("Enter Time in seconds for how long to finish a cycle of recurring hue color changes: "));  // show some text
	groupScheduleRecur = new WLineEdit(root());
	
	WPushButton *groupScheduleRecur2 = new WPushButton("Start Light Recur", root());              // create a button for deleting groups
	groupScheduleRecur2->clicked().connect(this, &HueApplication::recurLightNum); 
	WPushButton *groupScheduleRecur23 = new WPushButton("Start Group Recur", root());              // create a button for deleting groups
	groupScheduleRecur23->clicked().connect(this, &HueApplication::recurGroupHue); 


	WPushButton *recurStop = new WPushButton("Stop", root());              // create a button for deleting groups
	recurStop->clicked().connect(this, &HueApplication::stopRecur); 
	root()->addWidget(new WText("<br />")); 
	WPushButton *holidayButton = new WPushButton("Set light for closest Holiday", root());              // create a button for deleting groups
	holidayButton->clicked().connect(this, &HueApplication::setHolidayLights);  
 	root()->addWidget(new WText("<br />")); 
	root()->addWidget(new WText("Name the group"));  // show some text
	groupName_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("Enter which lights to group(separate by comma no duplicates)"));  // show some text
	lightsListString_ = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	WPushButton *groupLight = new WPushButton("Create Group", root());              // create a button for creating groupes
	groupLight->clicked().connect(this, &HueApplication::createGroup); 
  
	root()->addWidget(new WText("<br />"));
	root()->addWidget(new WText("<br/>Enter group number to edit"));  // show some text
	groupNumber_ = new WLineEdit(root()); 
	WPushButton *groupStatesButton = new WPushButton("Change Group States", root());              // create a button for editing group states
	groupStatesButton->clicked().connect(this, &HueApplication::editGroup);

	WPushButton *getGroupsButton = new WPushButton("Get all groups", root());              // create a button for getting all group states
	getGroupsButton->clicked().connect(this, &HueApplication::getGroupStates);  


	WPushButton *getGroupsButton2 = new WPushButton("Get group states", root());              // create a button for getting group states
	getGroupsButton2->clicked().connect(this, &HueApplication::getSpecificGroup);  
  
	WPushButton *deleteGroupB = new WPushButton("Delete group", root());              // create a button for deleting groups
	deleteGroupB->clicked().connect(this, &HueApplication::deleteGroup);     

   root()->addWidget(new WText("<br/>--------------------Scheduler--------------------"));
	root()->addWidget(new WText("<br/>Schedule Name:"));  // show some text
	scheduleName_ = new WLineEdit(root());
	root()->addWidget(new WText("Schedule Description:"));  // show some text
	scheduleDesc_ = new WLineEdit(root());


	root()->addWidget(new WText("<br/>Enter Year [YYYY]: "));  // show some text
	scheduleYear_ = new WLineEdit(root());

	root()->addWidget(new WText("Enter Month [MM]: "));  // show some text
	scheduleMonth_ = new WLineEdit(root());  

	root()->addWidget(new WText("Enter Day [DD]: "));  // show some text
	scheduleDay_ = new WLineEdit(root());  
    
	root()->addWidget(new WText("<br/>Enter Hours [HH]: "));  // show some text
	scheduleHours_ = new WLineEdit(root());  

	root()->addWidget(new WText("Enter Minutes [MM]: "));  // show some text
	scheduleMinutes_ = new WLineEdit(root());  

	root()->addWidget(new WText("Enter Seconds [SS]: "));  // show some text
	scheduleSeconds_ = new WLineEdit(root()); 
          
          
	root()->addWidget(new WText("<br />light/group num"));  // show some text
	lightNum_2 = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	root()->addWidget(new WText("light/group state (on/off)"));  // show some text
	lightState_2 = new WLineEdit(root());  



	root()->addWidget(new WText("light/group brightness(1-254)"));  // show some text
	bri_2 = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));


	root()->addWidget(new WText("light/group hue(0-65535)"));  // show some text
	hue_2 = new WLineEdit(root());  


	root()->addWidget(new WText("light/group transition time (>0)"));  // show some text
	transitiontime_2 = new WLineEdit(root());  
	root()->addWidget(new WText("<br />"));

	WPushButton *lightSchedule = new WPushButton("Schedule Light", root());              // create a button for deleting groups
	lightSchedule->clicked().connect(this, &HueApplication::scheduleLight);  
	WPushButton *groupSchedule = new WPushButton("Schedule Group", root());              // create a button for deleting groups
	groupSchedule->clicked().connect(this, &HueApplication::scheduleGroup);  

	WPushButton *groupSchedule2 = new WPushButton("Get All Schedules", root());              // create a button for deleting groups
	groupSchedule2->clicked().connect(this, &HueApplication::getSchedules); 

 



	root()->addWidget(new WText("Enter schedule ID: "));  // show some text
	scheduleID_ = new WLineEdit(root());
	  
	WPushButton *groupSchedule6 = new WPushButton("Get Schedule Information", root());              // create a button for deleting groups
	groupSchedule6->clicked().connect(this, &HueApplication::getSingleSchedule);  	  

	WPushButton *groupSchedule4 = new WPushButton("Edit Schedule", root());              // create a button for deleting groups
	groupSchedule4->clicked().connect(this, &HueApplication::editSchedule); 

	WPushButton *groupSchedule3 = new WPushButton("Remove Schedule", root());              // create a button for deleting groups
	groupSchedule3->clicked().connect(this, &HueApplication::deleteSchedule);  



	response_ = new WText(root());                                
	response_->setWordWrap(false);// allow for line breaks


}
//-----------------------------------------------scheduler functions-------------------------------
  /** 
  *   @brief  Changes light 1 based off the closest holiday. Currently only supports Halloween and Christmas  
  *  
  *   @param  a is an initialized string variable holding the holiday that is closest to the current date
  *   @return void
  */ 
void holidayLight1(std::string theHoliday){
	if(theHoliday=="christmas"){
		Bridge theBridge=*cur_bridge_;
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/1/state"; 
		std::string bodyMsg="{\"hue\":"+std::to_string(65535)+",\"bri\":"+std::to_string(254)+",}";
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){	// send a put response to light 1 from the selected bridge
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
	}
	if(theHoliday=="halloween"){
		Bridge theBridge=*cur_bridge_;
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/2/state";
		std::string bodyMsg="{\"hue\":"+std::to_string(65535)+",\"bri\":"+std::to_string(254)+",}";
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){	// send a put response to light 2 from the selected bridge
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
	}
}
  /** 
  *   @brief  Changes light 2 based off the closest holiday. Currently only supports Halloween and Christmas  
  *  
  *   @param  a is an initialized string variable holding the holiday that is closest to the current date
  *   @return void
  */ 
void holidayLight2(std::string theHoliday){
	if(theHoliday=="christmas"){
		Bridge theBridge=*cur_bridge_;
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/2/state";
		std::string bodyMsg="{\"hue\":"+std::to_string(25000)+",\"bri\":"+std::to_string(254)+",}";
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){	// send a put response to light 2 from the selected bridge
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
	}
	if(theHoliday=="halloween"){
		Bridge theBridge=*cur_bridge_;
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/2/state";
		std::string bodyMsg="{\"hue\":"+std::to_string(10000)+",\"bri\":"+std::to_string(20)+",}";
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
	}
}
  /** 
  *   @brief  Changes light 3 based off the closest holiday. Currently only supports Halloween and Christmas  
  *  
  *   @param  a is an initialized string variable holding the holiday that is closest to the current date
  *   @return void
  */ 
void holidayLight3(std::string theHoliday){
	if(theHoliday=="christmas"){
		Bridge theBridge=*cur_bridge_;
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/3/state";
		std::string bodyMsg="{\"hue\":"+std::to_string(10000)+",\"bri\":"+std::to_string(254)+",}";
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){	// send a put response to light 3 from the selected bridge
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
	}
	if(theHoliday=="halloween"){
		Bridge theBridge=*cur_bridge_;
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/2/state";
		std::string bodyMsg="{\"hue\":"+std::to_string(10000)+",\"bri\":"+std::to_string(254)+",}";
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){	// send a put response to light 3 from the selected bridge
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
	}
}
  /** 
  *   @brief  An additional feature: Changes 3 lights for the selected bridge based off the closest holiday. Currently only supports Christmas and Halloween
  *   @return void
  */ 
void setHolidayLights(){ // additional feature - holiday theme me
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before trying the Holiday feature");
		return;
	}
	time_t t=time(NULL);
	tm *timePtr=localtime(&t);
	int curDay=timePtr->tm_yday;//current day of year
	std::string holiday;
	int christmas  = 359;//day of the year that christmas is
	int halloween  = 304;//day of the year that halloween is
	if(abs(curDay-christmas)<abs(curDay-halloween)){//check which day is closest to current day
		holiday="christmas";//christmas theme the lights
		holidayLight1("christmas");
		holidayLight2("christmas");
		holidayLight3("christmas");
		response_->setText("<br/>Christmas is/was closer than Halloween. Displaying Christmas themed lights!");	
	}
	else{
		holiday="halloween";//christmas theme the lights
		holidayLight1("halloween");
		holidayLight2("halloween");
		holidayLight3("halloween");
		response_->setText("<br/>halloween is/was closer than Christmas. Displaying Halloween themed lights!");
	}
}


  /** 
  *   @brief  An asynchronous function which changes the hue of a selected group continuously until the user presses the stop button (which calls the stopRecur function)
  *   @return void
  */ 
void asyncRcur2(){

	std::string bodyMsg;
	
	int times=atoi(groupScheduleRecur->text().toUTF8().c_str());//convert the user inputted time to int
	if(times<=0){//if its invalid or they put a negative number default it to 2
		times=2;
	}
	int hueChange=65535/times; // due a full hue cycle in the user inputted time
	int curHue=0;
	Bridge theBridge=*cur_bridge_;
	std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups/" + groupNumber_->text().toUTF8()+"/action";
	while(recurring){ // continue changing the hue while the user has a recurring schedule running
		bodyMsg="{\"hue\":"+std::to_string(curHue)+"}";
		curHue+=hueChange;
		curHue%=65535;
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){
		//	WApplication::instance()->deferRendering();
		}
	//	Wt::WServer::instance()->ioService().post(boost::bind(&HueApplication::asyncRcur,this));
		//client->done().connect(boost::bind(&HueApplication::handleHttpResponseRecur, this, _1, _2));
		std::this_thread::sleep_for(std::chrono::seconds(1));
		
	}
}
  /** 
  *   @brief  An asynchronous function which changes the hue of a selected light continuously until the user presses the stop button (which calls the stopRecur function)
  *   @return void
  */ 
void asyncRcur(){
	std::string bodyMsg;
	int times=atoi(groupScheduleRecur->text().toUTF8().c_str());//convert the user inputted time to int
	if(times<=0){
		times=2;//if its invalid or they put a negative number default it to 2
	}
	int hueChange=65535/times;// due a full hue cycle in the user inputted time
	int curHue=0;
	Bridge theBridge=*cur_bridge_;
	std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/" + lightNum_->text().toUTF8()+"/state";
	while(recurring){// continue changing the hue while the user has a recurring schedule running
		bodyMsg="{\"hue\":"+std::to_string(curHue)+"}";
		curHue+=hueChange;
		curHue%=65535;
		Http::Client *client = new Http::Client(this);
		Wt::Http::Message message;
		client->setTimeout(15);
		client->setMaximumResponseSize(10 * 1024);
		message.addBodyText(bodyMsg);
		if(client->put(url, message)){//send a put request to change the hue of the group inside the loop
		//	WApplication::instance()->deferRendering(); - this is a thread so not needed
		}
		std::this_thread::sleep_for(std::chrono::seconds(1));
		
	}
}
//stops all reccuring schedules
  /** 
  *   @brief  Stops all recurring hue light/group schedules
  *   @return void
  */ 
void stopRecur(){
	recurring=false;
}

  /** 
  *   @brief  Initiaiates the reccuring hue light change cycle. This function asynchronously calls asyncRcur
  *   @return void
  */ 
void recurLightNum(){
	if(recurring==true){
		response_->setText("<br/>You are already running a reccuring schedule! This feature only works one at a time");
		return;
	}
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before editing a light");
		return;
	}
	if(lightNum_->text().toUTF8()==""){
		response_->setText("<br/>specify a light number first");
		return;
	}
	if(groupScheduleRecur->text().toUTF8()==""){
		response_->setText("<br/>specify a time for how long to do a hue cycle first");
		return;
	}
	recurring=true;
	Wt::WServer::instance()->ioService().post(boost::bind(&HueApplication::asyncRcur,this));//need to call this asynchronously so it does not hang the program
	//std::future<void> fut = std::async(boost::bind(&HueApplication::asyncRcur,this));
	//fut.get();
}
  /** 
  *   @brief  Initiaiates the reccuring hue light change cycle for the selected group. This function asynchronously calls asyncRcur2
  *   @return void
  */  
void recurGroupHue(){
	if(recurring==true){
		response_->setText("<br/>You are already running a reccuring schedule! This feature only works one at a time");
		return;
	}
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before editing a group");
		return;
	}
	if(groupNumber_->text().toUTF8()==""){
		response_->setText("<br/>specify a group number first");
		return;
	}
	if(groupScheduleRecur->text().toUTF8()==""){
		response_->setText("<br/>specify a time for how long to do a hue cycle first");
		return;
	}
	recurring=true;
	Wt::WServer::instance()->ioService().post(boost::bind(&HueApplication::asyncRcur2,this));//need to call this asynchronously so it does not hang the program
	//std::future<void> fut = std::async(boost::bind(&HueApplication::asyncRcur,this));
	//fut.get();
}


  /** 
  *   @brief  ALlows the user to edit an existing schedule if they have a bridge,schedule id, and group number specified
  *   @return void
  */
void editSchedule(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge first");
		return;
	}
	if(scheduleID_->text().toUTF8()==""){
		response_->setText("<br/>specify a schedule ID first");
		return;
	}

	if(lightNum_2->text().toUTF8()==""){
		response_->setText("<br/>specify a group number first");
		return;
	}
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string lightstateString=ligtName_->text().toUTF8();
	//get the url for the schedule request
	std::string url = "http://"+theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/schedules/"+scheduleID_->text().toUTF8();
	std::string url2 ="/api/" + theBridge.getUserName() + "/groups/"+lightNum_2->text().toUTF8()+"/action";//get the url for the group change
	std::string stateStringer=lightState_2->text().toUTF8();

	//create the json string below using the user inputted fields
	if(lightState_2->text().toUTF8()!=""){
		if(stateStringer=="on"||stateStringer=="1"||stateStringer=="true"||stateStringer=="True"||stateStringer=="TRUE"){
			stateStringer="true";
		}
		else if(stateStringer=="off"||stateStringer=="0"||stateStringer=="false"||stateStringer=="False"||stateStringer=="FALSE"){
			stateStringer="false";
		}
	}
	bodymsg="{";
	if(scheduleName_->text().toUTF8()!=""){
		bodymsg+="\"name\":\"" + scheduleName_->text().toUTF8() + "\",";
	}
	else{
		bodymsg+="\"name\":\"schedule\",";
	}
	if(scheduleDesc_->text().toUTF8()!=""){
		bodymsg+="\"description\":\"" + scheduleName_->text().toUTF8() + "\"";
	}
	else{
		bodymsg+="\"description\":\"\"";
	}
	bodymsg+=",\"command\": { \"address\":\"" + url2 + "\",\"method\": \"PUT\", \"body\": {";
	if(lightState_2->text().toUTF8()!=""){
		bodymsg+="\"on\":" + stateStringer+",";
	}
	if(hue_2->text().toUTF8()!=""){
		bodymsg+= "\"hue\":" + hue_2->text().toUTF8()+",";
	}
	if(bri_2->text().toUTF8()!=""){
		bodymsg+= "\"bri\":" + bri_2->text().toUTF8()+",";
	}
	if(transitiontime_2->text().toUTF8()!=""){
		bodymsg+= "\"transitiontime\":" + transitiontime_2->text().toUTF8();
	}
	if(bodymsg.back()==','){
		bodymsg.erase(bodymsg.size() - 1);	
	}
	bodymsg+="}},";
	std::string theTime="\""+scheduleYear_->text().toUTF8()+"-"+scheduleMonth_->text().toUTF8()+"-"+scheduleDay_->text().toUTF8()+"T"+scheduleHours_->text().toUTF8()+":"+scheduleMinutes_->text().toUTF8()+":"+scheduleSeconds_->text().toUTF8()+"\"";
	bodymsg+= "\"time\":" + theTime + "}";
		//finished creating the json
	message.addBodyText(bodymsg);
	
	if(client->put(url, message)){ // send the json to the emulator
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom1, this, _1, _2));
	


}

  /** 
  *   @brief  ALlows the user to delete a schedule if they specified a bridge and a schedule ID
  *   @return void
  */ 
void deleteSchedule(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge first");
		return;
	}
	if(scheduleID_->text().toUTF8()==""){
		response_->setText("<br/>specify a schedule ID first");
		return;
	}
	
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	message.addBodyText("");
	Bridge theBridge=*cur_bridge_;
	//get the url for the deleterequest
	std::string url = "http://"+theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/schedules/"+scheduleID_->text().toUTF8();
	if(client->deleteRequest(url,message)){//delete request
		WApplication::instance()->deferRendering();
	}
	response_->setText("<br/>Succesfully deleted schedule ID: "+scheduleID_->text().toUTF8()+" (if it existed)");
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom2, this, _1, _2));

}

  /** 
  *   @brief  Returns all schedules for a specified bridge
  *   @return void
  */ 
void getSchedules(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge first");
		return;
	}

	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string url = "http://"+theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/schedules";

	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	if(client->get(url)){
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
}

  /** 
  *   @brief  Returns information on a schedule based off the schedule id
  *   @return void
  */ 
void getSingleSchedule(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge first");
		return;
	}

	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string url = "http://"+theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/schedules/"+scheduleID_->text().toUTF8();

	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	if(client->get(url)){
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
}
  /** 
  *   @brief  Creates a schedule for a specified bridge and group
  *   @return void
  */ 
void scheduleGroup(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge first");
		return;
	}

	if(lightNum_2->text().toUTF8()==""){
		response_->setText("<br/>specify a group number first");
		return;
	}
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string lightstateString=ligtName_->text().toUTF8();
	//get the url for the schedule
	std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/schedules";
	//get the url for editing the group inside the schedule
	std::string url2 ="/api/" + theBridge.getUserName() + "/groups/"+lightNum_2->text().toUTF8()+"/action";
	std::string stateStringer=lightState_2->text().toUTF8();
	//create the JSON formatted string below
	if(lightState_2->text().toUTF8()!=""){
		if(stateStringer=="on"||stateStringer=="1"||stateStringer=="true"||stateStringer=="True"||stateStringer=="TRUE"){
			stateStringer="true";
		}
		else if(stateStringer=="off"||stateStringer=="0"||stateStringer=="false"||stateStringer=="False"||stateStringer=="FALSE"){
			stateStringer="false";
		}
	}
	bodymsg="{";
	if(scheduleName_->text().toUTF8()!=""){
		bodymsg+="\"name\":\"" + scheduleName_->text().toUTF8() + "\",";
	}
	else{
		bodymsg+="\"name\":\"schedule\",";
	}
	if(scheduleDesc_->text().toUTF8()!=""){
		bodymsg+="\"description\":\"" + scheduleName_->text().toUTF8() + "\"";
	}
	else{
		bodymsg+="\"description\":\"\"";
	}
	bodymsg+=",\"command\": { \"address\":\"" + url2 + "\",\"method\": \"PUT\", \"body\": {";
	if(lightState_2->text().toUTF8()!=""){
		bodymsg+="\"on\":" + stateStringer+",";
	}
	if(hue_2->text().toUTF8()!=""){
		bodymsg+= "\"hue\":" + hue_2->text().toUTF8()+",";
	}
	if(bri_2->text().toUTF8()!=""){
		bodymsg+= "\"bri\":" + bri_2->text().toUTF8()+",";
	}
	if(transitiontime_2->text().toUTF8()!=""){
		bodymsg+= "\"transitiontime\":" + transitiontime_2->text().toUTF8();
	}
	if(bodymsg.back()==','){
		bodymsg.erase(bodymsg.size() - 1);	
	}
	bodymsg+="}},";
	//done creating the JSON formatted string
	std::string theTime="\""+scheduleYear_->text().toUTF8()+"-"+scheduleMonth_->text().toUTF8()+"-"+scheduleDay_->text().toUTF8()+"T"+scheduleHours_->text().toUTF8()+":"+scheduleMinutes_->text().toUTF8()+":"+scheduleSeconds_->text().toUTF8()+"\"";
	bodymsg+= "\"time\":" + theTime + "}";
	
	message.addBodyText(bodymsg);
	if(client->post(url, message)){
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom2, this, _1, _2));
}	

  /** 
  *   @brief  Creates a schedule for a light inside a specified bridge
  *   @return void
  */
void scheduleLight(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge first");
		return;
	}

	if(lightNum_2->text().toUTF8()==""){
		response_->setText("<br/>specify a light number first");
		return;
	}
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string lightstateString=ligtName_->text().toUTF8();
	//get the urls for the schedule...
	std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/schedules";
	std::string url2 ="/api/" + theBridge.getUserName() + "/lights/"+lightNum_2->text().toUTF8()+"/state";
	std::string stateStringer=lightState_2->text().toUTF8();
	//create the json
	if(lightState_2->text().toUTF8()!=""){
		if(stateStringer=="on"||stateStringer=="1"||stateStringer=="true"||stateStringer=="True"||stateStringer=="TRUE"){
			stateStringer="true";
		}
		else if(stateStringer=="off"||stateStringer=="0"||stateStringer=="false"||stateStringer=="False"||stateStringer=="FALSE"){
			stateStringer="false";
		}
	}
	bodymsg="{";
	if(scheduleName_->text().toUTF8()!=""){
		bodymsg+="\"name\":\"" + scheduleName_->text().toUTF8() + "\",";
	}
	else{
		bodymsg+="\"name\":\"schedule\",";
	}
	if(scheduleDesc_->text().toUTF8()!=""){
		bodymsg+="\"description\":\"" + scheduleName_->text().toUTF8() + "\"";
	}
	else{
		bodymsg+="\"description\":\"\"";
	}
	bodymsg+=",\"command\": { \"address\":\"" + url2 + "\",\"method\": \"PUT\", \"body\": {";
	if(lightState_2->text().toUTF8()!=""){
		bodymsg+="\"on\":" + stateStringer+",";
	}
	if(hue_2->text().toUTF8()!=""){
		bodymsg+= "\"hue\":" + hue_2->text().toUTF8()+",";
	}
	if(bri_2->text().toUTF8()!=""){
		bodymsg+= "\"bri\":" + bri_2->text().toUTF8()+",";
	}
	if(transitiontime_2->text().toUTF8()!=""){
		bodymsg+= "\"transitiontime\":" + transitiontime_2->text().toUTF8();
	}
	if(bodymsg.back()==','){
		bodymsg.erase(bodymsg.size() - 1);	
	}
	bodymsg+="}},";
	std::string theTime="\""+scheduleYear_->text().toUTF8()+"-"+scheduleMonth_->text().toUTF8()+"-"+scheduleDay_->text().toUTF8()+"T"+scheduleHours_->text().toUTF8()+":"+scheduleMinutes_->text().toUTF8()+":"+scheduleSeconds_->text().toUTF8()+"\"";
	bodymsg+= "\"time\":" + theTime + "}";
	//done creating JSON string
	message.addBodyText(bodymsg);
	if(client->post(url, message)){
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom2, this, _1, _2));
}	

//-----------------------------------------------bridge functions-----------------------------------
  /** 
  *   @brief  Creates a bridge and stores it inside the database linked to the user given the user inputs valid information and it can be linked to the emulator
  *   @return void
  */ 
void createBridge(){
		//validate all the bridge info here before creating it and giving to session of user
	std::string testInput=nameEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter a name for the bridge!");
		return;
	}
	testInput=ipEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter an ip address for the bridge!");
		return;
	}
	testInput=portEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter a port for the bridge!");
		return;
	} 	
	testInput=locationEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter a location for the bridge!");
		return;
	} 	

		
	Bridge theBridge;
	theBridge.setDetails(nameEdit_->text().toUTF8(),ipEdit_->text().toUTF8(),portEdit_->text().toUTF8(),locationEdit_->text().toUTF8(),usernameEdit_->text().toUTF8()); 
	
	std::string url = "http://"+ theBridge.getIp() +":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights";// 
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCreateBridge, this, _1, _2));
	if (client->get(url)){
		WApplication::instance()->deferRendering();
	}
}
  /** 
  *   @brief  Displays all bridges owned by the user onto the bottom of the screen
  *   @return void
  */ 
void displayBridges(){
	std::string outputer;
	Wt::Dbo::collection <dbo::ptr<Bridge>> bridgeCol;
	//----------------------------grab from database-------------------
	dbo::Transaction transaction2(session_);
	bridgeCol=session_.query< Wt::Dbo::ptr<Bridge> >("select u from \"bridges\" u where \"user2_id\" = ?").bind(session_.user().id()).orderBy("id");
	for(Wt::Dbo::collection<Wt::Dbo::ptr<Bridge>>::iterator tester=bridgeCol.begin();tester!=bridgeCol.end();tester++){//off by 1 error not showing first bridge@#$%$^&
		Bridge theBridge=*tester->get();
		Wt::Dbo::ptr<Bridge> fk=*tester;
		
		outputer+="<br/>--------------<br/>bridge id: "+std::to_string(fk.id())+"<br/>bridge ip:"+theBridge.getIp()+"<br/>Name: "+theBridge.getName()+"<br/>Ip:"+ theBridge.getIp()+"<br/>Port:"+ theBridge.getPort()+"<br/>Location:"+ theBridge.getlocation()+"<br/> 				UserName:"+ theBridge.getUserName();
		
	}
	transaction2.commit();
	//----------------------------grab from database-------------------
	response_->setText(outputer);
}

  /** 
  *   @brief  Selects a bridge based off bridge ID. to find a specific bridge id press get all bridges and parse through
  *   @return void
  */ 

void selectBridge(){
	dbo::Transaction transaction2(session_);
	cur_bridge_ = session_.query< Wt::Dbo::ptr<Bridge> >("select u from \"bridges\" u where \"id\" = ?").bind(bridgeIDSelect_->text().toUTF8());
	transaction2.commit();
	if(!cur_bridge_){
		response_->setText("</br>Could not find bridge with that matching ID!");
		return;
	}
    Bridge theBridge=*cur_bridge_;
	response_->setText("<br/>New bridge selected by id: "+bridgeIDSelect_->text().toUTF8()+ "<br/>Name: " +theBridge.getName()+"<br/>Ip:"+ theBridge.getIp()+"<br/>Port:"+ theBridge.getPort()+"<br/>Location:"+ theBridge.getlocation()
	+"<br/> UserName:"+ theBridge.getUserName());
	hasABridge=true;
}

  /** 
  *   @brief  Deletes a bridge based off the selected bridge id input field
  *   @return void
  */ 
void deleteBridge(){
	if(bridgeIDSelect_->text().toUTF8()==""){
		response_->setText("<br/>Specify a bridge ID first!");
		return;
	}
	//--------------------delete from database -------------
	Wt::Dbo::Transaction transaction2{session_};
	Wt::Dbo::ptr<Bridge> gottenBridge = session_.query< Wt::Dbo::ptr<Bridge> >("select u from \"bridges\" u where \"id\" = ?").bind(bridgeIDSelect_->text().toUTF8());
	gottenBridge.remove();
	transaction2.commit();
	//--------------------delete from database -------------
	response_->setText("<br/>Removed bridge with id: "+bridgeIDSelect_->text().toUTF8()+" (if it existed)");
	hasABridge=false;
	//need the user to select a new bridge now
}


  /** 
  *   @brief  Edits the information inside a bridge
  *   @return void
  */ 
void editBridge(){
	if(bridgeIDSelect_->text().toUTF8()==""){
		response_->setText("<br/>Specify a bridge ID first!");
		return;
	}
//id
	std::string testInput=nameEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter a name for the bridge!");
		return;
	}
	testInput=ipEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter an ip address for the bridge!");
		return;
	}
	testInput=portEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter a port for the bridge!");
		return;
	} 	
	testInput=locationEdit_->text().toUTF8();
	if(testInput==""){
		response_->setText("<br/>Enter a location for the bridge!");
		return;
	} 	
	//will need to query to grab the bridge
	Wt::Dbo::ptr<Bridge> gottenBridge;
	Wt::Dbo::Transaction transaction2{session_};
	gottenBridge = session_.query< Wt::Dbo::ptr<Bridge> >("select u from \"bridges\" u where \"id\" = ?").bind(bridgeIDSelect_->text().toUTF8());
	if(gottenBridge){
		gottenBridge.modify()->setDetails(nameEdit_->text().toUTF8(),ipEdit_->text().toUTF8(),portEdit_->text().toUTF8(),locationEdit_->text().toUTF8(),usernameEdit_->text().toUTF8()); 
 	}
	else{
		response_->setText("<br/>bridge does not exist in database");
	}
	transaction2.commit();
	//bridge was edited
	if(gottenBridge){
		Bridge theBridge=*gottenBridge;
		response_->setText("<br/>Edited bridge with id: : "+bridgeIDSelect_->text().toUTF8()+"<br/>bridged created succesfully <br/>Name: " +theBridge.getName()+"<br/>Ip:"+ theBridge.getIp()+"<br/>Port:"+ theBridge.getPort()+"<br/>Location:"+ theBridge.getlocation()+"<br/> UserName:"+ theBridge.getUserName()); 
	}
}
//-------------------------------------------------------------------light functions-------------------------

  /** 
  *   @brief  ALlows the user to change the name of a light is called automatically by changelightvariables
  *   @return void
  */ 

void changeLightName(){//put stuff for lights
	if(ligtName_->text().toUTF8()==""){
		response_->setText("<br/>specify a light number first");
		return;
	}
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string lightstateString=ligtName_->text().toUTF8();
	//create the name json string for the put request
	bodymsg = "{\"name\":"+lightstateString+"}";
	message.addBodyText(bodymsg);
	//get the url for the put request
	std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/" + lightNum_->text().toUTF8();
	if(client->put(url, message)){	// send a put request to change light name
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
	response_->setText(url);
}

  /** 
  *   @brief  Allows the user to change the states and attributes of a specified light based off the user inputted fields
  *   @return void
  */ 
void changeLightVariables(){//post stuff for lights
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before editing a light");
		return;
	}

	if(lightNum_->text().toUTF8()==""){
		response_->setText("<br/>specify a light number first");
		return;
	}
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	std::string lightstateString=lightState_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower); // conver to lowercase
	//create the json below
	bodymsg="{";
	bool validinput=false;
	if(lightstateString.length()>0){
		if(lightstateString=="off"||lightstateString=="false"||lightstateString=="0"){
			validinput=true;
			bodymsg += "\"on\":false,";//this is getting recieved by the emulator but not actually changing
		}
		else if(lightstateString=="on"||lightstateString=="1"||lightstateString=="true"){
			validinput=true;
			bodymsg += "\"on\":true,";//this is getting recieved by the emulator but not actually changing
		}
	}
	else{
		validinput=true;
	}
	lightstateString=bri_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower);
	validinput=false;
	int testInput=std::atoi(lightstateString.c_str());
	if(lightstateString.length()>0){
		if(testInput>0&&testInput<255){
			validinput=true;
			bodymsg += "\"bri\":"+std::to_string(testInput)+",";//this is getting recieved by the emulator but not actually changing
		}
	}
	else{
		validinput=true;
	}

	lightstateString=hue_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower);
	validinput=false;
	testInput=std::atoi(lightstateString.c_str());
	if(lightstateString.length()>0){
		if(testInput>=0&&testInput<=65535){
			validinput=true;
			bodymsg += "\"hue\":"+std::to_string(testInput)+",";//this is getting recieved by the emulator but not actually changing
		}
	}
	else{
		validinput=true;
	}
	lightstateString=transitiontime_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower);
	validinput=false;
	testInput=std::atoi(lightstateString.c_str());
	if(lightstateString.length()>0){
		if(testInput>=0){
			bodymsg += "\"transitiontime\":"+std::to_string(testInput)+",";//this is getting recieved by the emulator but not actually changing
			validinput=true;
		}
	}
	else{
		validinput=true;
	}
	if(bodymsg.back()==','){
		bodymsg.erase(bodymsg.size() - 1);	
	}
	bodymsg+="}";
	//done creating the json
	if(validinput){	// if the info was valid
		message.addBodyText(bodymsg);
		Bridge theBridge=*cur_bridge_;//grab the currently selected bridge
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/" + lightNum_->text().toUTF8()+"/state";
		if(client->put(url, message)){
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
		response_->setText(url);
		changeLightName(); // change the name of the light as well
	}

}

	
  /** 
  *   @brief  Displays all the lights inside a speciied bridge onto the bottom of the page
  *   @return void
  */ 
void getAllLights(){
	if(!hasABridge){
		response_->setText("<br/> specify a bridge first!");
		return;
	}
	Bridge theBridge=*cur_bridge_;
	std::string url = "http://"+ theBridge.getIp() +":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights";// 
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
	if (client->get(url)){
		WApplication::instance()->deferRendering();
	}	
	
}

  /** 
  *   @brief  Displays a specific light onto the bottom of the page
  *   @return void
  */ 
void getLight(){//get a specific light
	if(!hasABridge){
		response_->setText("<br/> specify a bridge first!");
		return;
	}
	if(lightNum_->text().toUTF8()==""){
	response_->setText("<br/> specify a light id first!");
	return;
	}
	Bridge theBridge=*cur_bridge_;
	//create url for the json request
	std::string url = "http://"+ theBridge.getIp() +":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/lights/"+lightNum_->text().toUTF8();// 
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	
	if (client->get(url)){	// get informatin the emulator with this url
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
}



	//------------------------------------group functions-------------------------------------------------

  /** 
  *   @brief  Get all the group IDs and names
  *   @return void
  */ 
void getGroupStates(){//get all groups

	if(!hasABridge){//no bridge selected
		response_->setText("<br/>specify a bridge before getting group information");
		return;
	}

	Bridge theBridge=*cur_bridge_;//grab the currently selected bridge
	std::string url = "http://"+ theBridge.getIp() +":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups";// url for groups
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);

	if (client->get(url)){//get a response
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom1, this, _1, _2));//response finishes
}

  /** 
  *   @brief  Displays information on a specific group based off the user inputted group number field (corresponds to group id from getgroupstates)
  *   @return void
  */ 
void getSpecificGroup(){ // get a specific group
	if(!hasABridge){//need to have a bridge selected
		response_->setText("<br/>specify a bridge before getting group information");
		return;
	}
	if(groupNumber_->text().toUTF8()==""){//need to have a group number specified
		response_->setText("<br/>specify a group number to the left first");
		return;
	}


	Bridge theBridge=*cur_bridge_;// grab the currently selected bridge
	std::string url = "http://"+ theBridge.getIp() +":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups/"+groupNumber_->text().toUTF8();// 
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom1, this, _1, _2));
	if (client->get(url)){	// send a get request to the emulator for the created url
		WApplication::instance()->deferRendering();
	}
	else {
		response_->setText("\nfail");
	}

}
  /** 
  *   @brief  Allows the user to edit the states/attributes of a group based off the specified bridge and group number as well as all the user inputted fields for editing states
  *   @return void
  */ 
void editGroup(){//edit the currently selected group states such as name and which light ids are inside the group
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before getting group information");
		return;
	}
	if(groupNumber_->text().toUTF8()==""){
		response_->setText("<br/>specify a group number first!");
		return;
	}

	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	std::string lightstateString=lightState_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower);
	//create the json string
	bodymsg="{";
	bool validinput=false;
	bool needComma=false;
	if(lightstateString.length()>0){//if they are editing light states
		if(lightstateString=="off"||lightstateString=="false"||lightstateString=="0"){
			validinput=true;
			bodymsg += "\"on\":false";
			needComma=true;
		}
		else if(lightstateString=="on"||lightstateString=="1"||lightstateString=="true"){
			validinput=true;
			bodymsg += "\"on\":true";
			needComma=true;
		}
	}
	else{
		validinput=true;
	}
	lightstateString=bri_->text().toUTF8();//string of groups you want to edit
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower); // turn the string into lowercase
	validinput=false;
	int testInput=std::atoi(lightstateString.c_str());//turn into int
	if(lightstateString.length()>0){//if they r actually editing lights inside group
		if(testInput>0&&testInput<255){
			validinput=true;
			
			if(needComma){
				bodymsg += ",\"bri\":"+std::to_string(testInput);}
			else{
				bodymsg += "\"bri\":"+std::to_string(testInput);}
			needComma=true;
		}
	}
	else{
		validinput=true;
	}

	lightstateString=hue_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower);
	validinput=false;
	testInput=std::atoi(lightstateString.c_str());
	if(lightstateString.length()>0){
		if(testInput>=0&&testInput<=65535){
			validinput=true;
			
			if(needComma==true){
				bodymsg += ",\"hue\":"+std::to_string(testInput);
			}
			else{
				bodymsg += "\"hue\":"+std::to_string(testInput);
			}
			needComma=true;
		}
	}
	else{
		validinput=true;
	}
	lightstateString=transitiontime_->text().toUTF8();
	std::transform(lightstateString.begin(),lightstateString.end(),lightstateString.begin(),::tolower);
	validinput=false;
	testInput=std::atoi(lightstateString.c_str());
	if(lightstateString.length()>0){//if they are actually changing lights inside the group 
		if(testInput>=0){
			if(needComma){
				bodymsg += ",\"transitiontime\":"+std::to_string(testInput);
				validinput=true;
			}
			else{
				bodymsg += "\"transitiontime\":"+std::to_string(testInput);
				validinput=true;
			}
		}
	}
	else{
		validinput=true;
	}
	bodymsg+="}";
	//done creating the json string
	if(validinput){
		message.addBodyText(bodymsg);
		Bridge theBridge=*cur_bridge_;//grab the current bridge
		std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups/" + groupNumber_->text().toUTF8()+"/action";
		if(client->put(url, message)){
			WApplication::instance()->deferRendering();
		}
		client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
		//response_->setText("succesfully changed settings: "+url);
		changeGroupName();
	}
}

  /** 
  *   @brief  Creates a group based off the user inputted fields. Requires a bridge to be selected. Adds the group to the database
  *   @return void
  */ 
void createGroup(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before making a group");
		return;
	}

	Bridge theBridge=*cur_bridge_;
	std::string grpName=groupName_->text().toUTF8();
	if(grpName.length()<=0){
		response_->setText("<br/>Enter group name first");
		return;
	}
	if(lightsListString_->text().toUTF8()==""){
		response_->setText("<br/>Enter some lights first (numbers only. no duplicates.)");
		return;
	}


	std::string lightsList=lightsListString_->text().toUTF8();
	std::string::iterator end_pos=std::remove(lightsList.begin(),lightsList.end(),' ');//remove spaces
	lightsList.erase(end_pos,lightsList.end());//remove spaces


	std::vector<std::string> listoflights;
	std::size_t place;
	while (place != -1) {//split the string up into a vector with commas separating
		place = lightsList.find(",");
		listoflights.push_back(lightsList.substr(0,place));
		lightsList.erase(0,place+1);
	}
	std::string bodyMsg="{\"lights\": [";
	for(auto &ii : listoflights){ // loop through the vector until we match the id with the requested person
		bodyMsg+="\""+ii+"\",";
	}
	bodyMsg=bodyMsg.substr(0,bodyMsg.size()-1);
	bodyMsg+="]";
	bodyMsg+=",\"name\":\""+grpName+"\",\"type\": LightGroup}";

//----------------------------------------------------------------------add to database-----------------------
	dbo::Transaction transaction{session_};//add it to database
	dbo::ptr<Bridge> curBridge=cur_bridge_;
	cur_group_ = session_.add(new Group(grpName,lightsListString_->text().toUTF8()));
	cur_group_.modify()->bridge=curBridge;
	transaction.commit();
	//----------------------------------------------------------------------add to database-----------------------
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	message.addBodyText(bodyMsg);
	std::string url = "http://"+theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups";
	response_->setText(url);
	if(client->post(url, message)){	//post request for the above url
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom1, this, _1, _2));
}

  /** 
  *   @brief  Changes the name of a group. Automatically called by editgroup
  *   @return void
  */ 
  
void changeGroupName(){//change the name of the group = put statement
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before making a group");
		return;
	}
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	std::string bodymsg;
	Bridge theBridge=*cur_bridge_;
	std::string lightstateString=ligtName_->text().toUTF8();
	//format the json string
	bodymsg = "{\"name\":"+lightstateString+"}";
	message.addBodyText(bodymsg);
	//get the url for the put request based off the current bridge
	std::string url ="http://"+ theBridge.getIp() + ":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups/" + groupNumber_->text().toUTF8();
	if(client->put(url, message)){	//send a put request
		WApplication::instance()->deferRendering();
	}
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseJsonLink, this, _1, _2,url));
	response_->setText(url);
}


  /** 
  *   @brief  Deletes a group based of the user specified bridge and group number field
  *   @return void
  */ 
void deleteGroup(){
	if(!hasABridge){
		response_->setText("<br/>specify a bridge before getting group information");
		return;
	}
	if(groupNumber_->text().toUTF8()==""){
		response_->setText("<br/>specify a group number first!");
		return;
	}
	Bridge theBridge=*cur_bridge_;
	std::string url = "http://"+ theBridge.getIp() +":" + theBridge.getPort() + "/api/" + theBridge.getUserName() + "/groups/"+groupNumber_->text().toUTF8();// 
	Http::Client *client = new Http::Client(this);
	client->setTimeout(15);
	client->setMaximumResponseSize(10 * 1024);
	Wt::Http::Message message;
	message.addBodyText("");
	client->done().connect(boost::bind(&HueApplication::handleHttpResponseCustom1, this, _1, _2));
	if(client->deleteRequest(url, message)){
		WApplication::instance()->deferRendering();
	}
	else {
		response_->setText("<br/>fail");
	}
}





//-------------------http responses----------------------------------
  /** 
  *   @brief  The HTTP response for creating a bridge. This function adds the bridge to the users database if it was succesful and does not otherwise.   
  *  
  *   @param  err is a boost error_code type containg the error message for the httpresponse
  *   @param  response is a type message which contains the responses of the HTTP response call 
  *   @return void
  */ 
void handleHttpResponseCreateBridge(boost::system::error_code err, const Http::Message& response){//for recurring hue change
	WApplication::instance()->resumeRendering();
	if (!err) {
		if (response.status() == 200) {

		//----------------------------add it to the database 	--------------------
		
		dbo::Transaction transaction(session_);
		dbo::ptr<User> curUser=session_.user();
		cur_bridge_ = session_.add(new Bridge(nameEdit_->text().toUTF8(),ipEdit_->text().toUTF8(),portEdit_->text().toUTF8(),locationEdit_->text().toUTF8(),usernameEdit_->text().toUTF8()));
		cur_bridge_.modify()->user=curUser;
		transaction.commit();
		hasABridge=true;
		
		//----------------------------add it to the database 	--------------------
		Bridge theBridge=*cur_bridge_;
			response_->setText("<br/>bridged created succesfully <br/>Name: " +theBridge.getName()+"<br/>Ip:"+ theBridge.getIp()+"<br/>Port:"+ theBridge.getPort()+"<br/>Location:"+ 
				theBridge.getlocation()+"<br/> UserName:"+ theBridge.getUserName());
		return;
		}
	} else {
		Wt::log("error") << "Http::Client error: " << err.message();
		response_->setText("<br/>invalid bridge information!Could not link it to the emulator");
	}
}
  /** 
  *   @brief  The HTTP response for the custom recurring additional feature. No information is printed out for this response as it is continuously running   
  *  
  *   @param  err is a boost error_code type containg the error message for the httpresponse
  *   @param  response is a type message which contains the responses of the HTTP response call 
  *   @return void
  */ 
void handleHttpResponseRecur(boost::system::error_code err, const Http::Message& response){//for recurring hue change
	WApplication::instance()->resumeRendering();
	if (!err) {
		if (response.status() == 200) {
		//Bridge theBridge=*cur_bridge_;
		//=true;
		//response_->setText("<br/>bridged created succesfully <br/>Name: " +theBridge.getName()+"<br/>Ip:"+ theBridge.getIp()+"<br/>Port:"+ theBridge.getPort()+"<br/>Location:"+ 
		//	theBridge.getlocation()+"<br/> UserName:"+ theBridge.getUserName());
		return;
		}
	} else {
		Wt::log("error") << "Http::Client error: " << err.message();
		//response_->setText("\n invalid bridge information!");
	}
}

  /** 
  *   @brief  The HTTP response for anything that involves displaying JSON. links the user to a page that will show the response in json as well as displays the actual response  
  *  
  *   @param  err is a boost error_code type containg the error message for the httpresponse
  *   @param  response is a type message which contains the responses of the HTTP response call 
  *   @param  theUrl is a string containig the url of the response
  *   @return void
  */ 
void handleHttpResponseJsonLink(boost::system::error_code err, const Http::Message& response,std::string theUrl){//http response with a url to display as well
	WApplication::instance()->resumeRendering();
	if (!err) {
		if (response.status() == 200) {
			response_->setText("<br/>"+response.body()+"<br/>Visit this url to view in JSON format: "+theUrl);
			return;
		}
	} else {
		Wt::log("error") << "Http::Client error: " << err.message();
		response_->setText(response.body());
	}
}
  /** 
  *   @brief  The HTTP response for displaying a JSON string. Gives a custom error message if the response is empty
  *  
  *   @param  err is the error message for the httpresponse
  *   @param  response contains the responses of the HTTP response call 
  *   @return void
  */ 
void handleHttpResponseCustom1(boost::system::error_code err, const Http::Message& response){//http response normal
	WApplication::instance()->resumeRendering();
	if (!err) {
		if (response.status() == 200) {
		//*display response on page - show the json
			response_->setText("<br/>"+response.body());
			if(response.body()==""){
				response_->setText("<br/>error invalid input");
			}
			return;
		}	
  	} else {
		Wt::log("error") << "Http::Client error: " << err.message();
  	}
}
  /** 
  *   @brief  The HTTP response for displaying a JSON string
  *  
  *   @param  err is the error message for the httpresponse
  *   @param  response contains the responses of the HTTP response call 
  *   @return void
  */ 
void handleHttpResponseCustom2(boost::system::error_code err, const Http::Message& response){//http response normal
	WApplication::instance()->resumeRendering();
	if (!err) {
		if (response.status() == 200) {
		//*display response on page - show the json
			response_->setText("<br/>"+response.body());
			return;
		}	
  	} else {
  		//response_->setText("<br/>error invalid input");
		Wt::log("error") << "Http::Client error: " << err.message();
  	}
}
private:
	dbo::ptr<Bridge> cur_bridge_; ///<  holds a wt dbo pointer to the current specified bridge
	dbo::ptr<Group> cur_group_;	///< holds a wt dbo pointer to the current specified group
	bool hasABridge=false;	///< if the user has a speciifed bridge or not
	bool recurring=false;///<  if a recurring schedule is running or not
	bool bridgeSuccess=false;///< if it sucessfuly connected to the bridge or not
	WLineEdit *groupName_;	///< name of the group
	WLineEdit *lightsListString_;	///< list the lights to be placed inside a group
	WLineEdit *bri_;	///< a field for editing/setting the brightness of a specified group or light
	WLineEdit *hue_;	///< a field for editing/setting the hue of a specified group or light
	WLineEdit *groupScheduleRecur; ///< a field for how long the user wants it to take to do a full hue cycle in the recurring schedule
	WLineEdit *transitiontime_;	///< a field for editing/setting the transitiontime of a specified group or light
	WLineEdit *ligtName_;	///< a field for editing the name of a specified group or light
	WLineEdit *groupNumber_;	///< a field for specifying the group id
	WLineEdit *lightNum_;	///< a field for specifying the light id
	WLineEdit *lightState_;	///< a field for specifying the list of list sinside a group
	Session session_;	///< holds the current session
	WLineEdit *nameEdit_;	///< used to edit/specify the name of a bridge
	WLineEdit *ipEdit_;		///< used to edit/specify the ip of a bridge
	WLineEdit *locationEdit_;	///< used to edit/specify the location of a bridge
	WLineEdit *portEdit_;	///< used to edit/specify the port of a bridge
	WLineEdit *usernameEdit_;	///< used to edit/specify the username of a bridge
	WLineEdit *bridgeIDSelect_; 	///< used to select a certain bridge
	//---scheduler
	WLineEdit *scheduleYear_; 	///< used to edit/specify the year for the scheduler
	WLineEdit *scheduleMonth_;	///< used to edit/specify the month for the scheduler
	WLineEdit *scheduleDay_ ;	///< used to edit/specify the year for the scheduler
	WLineEdit *scheduleHours_; ///< used to edit/specify the hours for the scheduler
	WLineEdit *scheduleMinutes_; ///< used to edit/specify the minutes for the scheduler
	WLineEdit *scheduleSeconds_; ///< used to edit/specify the seconds for the scheduler
	WLineEdit *scheduleName_;///< used to edit/specify the name for the scheduler
	WLineEdit *scheduleDesc_;///< used to edit/specify the description for the scheduler
	WLineEdit *lightNum_2;	///< used to edit/specify the group/light number for the scheduler
	WLineEdit *lightState_2;	///< used to edit/specify the light state for the scheduler
	WLineEdit *bri_2;	///< used to edit/specify the brightness for the scheduler
	WLineEdit *hue_2;	///< used to edit/specify the hue for the scheduler
	WLineEdit *transitiontime_2;	///< used to edit/specify the transition time for the scheduler
	WLineEdit *scheduleID_;	///< used to specify the id of the scheduler
	//----scheduler
	
	WText *response_; 	///< displays the text at the bottom whenever the user does something
};

  /** 
  *   @brief  Creates the WT application
  *  
  *   @param  env is a WT envrionment which will create the app
  *   @return WT::WApplication creates the application based off the environment
  */ 
Wt::WApplication *createApplication(const Wt::WEnvironment& env){
  return new HueApplication(env);
}

  /** 
  *   @brief  THe main function. Creates the entry point and configures the auth for the WT app also initalizes the creation application method
  *  
  *   @param  argc holds the number of command line arguments
  *   @param  argv holds the command line arguments
  *   @return 0
  */ 
int main(int argc, char **argv){
	std::cout<<"started"<<std::endl;
	try {
		Wt::WServer server(argc, argv, WTHTTP_CONFIGURATION);
		server.addEntryPoint(Wt::Application, createApplication);
		Session::configureAuth();
		server.run();

	} catch (Wt::WServer::Exception& e) {
		std::cerr << e.what() << std::endl;
	} catch (std::exception &e) {
		std::cerr << "exception: " << e.what() << std::endl;
	}
}










