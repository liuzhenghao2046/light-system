/** 
 *  @file    RegistrationView.cpp
 *  @author  (zmaroofz) Zagros Maroofzadeh
 *  @date    28/11/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 final stage group project assignment1, creates and configures the registration view
 */
#include "RegistrationView.h"
#include "model/UserDetailsModel.h"
#include <Wt/WLineEdit>
#include <Wt/WApplication>
#include <Wt/WServer>


  /** 
  *   @brief  Constructor for the registration view. uses template.registration
  *  
  *   @param  authwidget configures the view based off the auth widget
  *   @return RegistrationView updates the view as well
  */ 
RegistrationView::RegistrationView(Session& session,Wt::Auth::AuthWidget *authWidget): Wt::Auth::RegistrationWidget(authWidget),session_(session){
  setTemplateText(tr("template.registration"));
  detailsModel_ = new UserDetailsModel(session_, this);

  updateView(detailsModel_);
}
  /** 
  *   @brief  Creates the form for registering
  *  
  *   @param  field the field to add to the form
  *   @return Wt:WWidget a widget for the register view
  */ 

Wt::WWidget *RegistrationView::createFormWidget(Wt::WFormModel::Field field){

 if(field == UserDetailsModel::firstNameField)
    return new Wt::WLineEdit();
  else if(field == UserDetailsModel::lastNameField)
    return new Wt::WLineEdit();
  else
    return Wt::Auth::RegistrationWidget::createFormWidget(field);
}

  /** 
  *   @brief  validates the entered fields
  *   @return bool whether the field is valid or not
  */ 

bool RegistrationView::validate(){
  bool result = Wt::Auth::RegistrationWidget::validate();

  updateModel(detailsModel_);
  if (!detailsModel_->validate())
    result = false;
  updateView(detailsModel_);

  return result;
}
  /** 
  *   @brief  Creates user details model for register view
  *   @return void
  */ 

void RegistrationView::registerUserDetails(Wt::Auth::User& user){
  detailsModel_->save(user);
}
