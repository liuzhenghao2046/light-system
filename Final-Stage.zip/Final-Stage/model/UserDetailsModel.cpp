/** 
 *  @file    MainApp.cpp
 *  @author  (zmaroofz) Zagros Maroofzadeh
 *  @date    28/11/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 final stage group project assignment1, holds information on the user details model
 */
#include "UserDetailsModel.h"
#include "User.h"
#include "Session.h"


const Wt::WFormModel::Field
UserDetailsModel::firstNameField = "first-name"; ///< field for first name

const Wt::WFormModel::Field
UserDetailsModel::lastNameField = "last-name"; ///< field for last name


  /** 
  *   @brief  Constructor for the user details
  */ 

UserDetailsModel::UserDetailsModel(Session& session, Wt::WObject *parent): Wt::WFormModel(parent),session_(session){
  addField(firstNameField, Wt::WString::tr("first-name-info"));
  addField(lastNameField, Wt::WString::tr("last-name-info"));
}

  /** 
  *   @brief  saves firstname and lastname of the user details
  *  
  *   @param  authUser a Wt::Auth::User type holding the user auth info
  *   @return void
  */ 
void UserDetailsModel::save(const Wt::Auth::User& authUser){
  Wt::Dbo::ptr<User> user = session_.user(authUser);
  
  user.modify()->firstName = valueText(firstNameField).toUTF8();
  user.modify()->lastName = valueText(lastNameField).toUTF8();
}
