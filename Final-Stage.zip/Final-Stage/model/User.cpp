#include <Wt/Dbo/Impl>
#include <Wt/Auth/Dbo/AuthInfo>
#include "User.h"
DBO_INSTANTIATE_TEMPLATES(User);

