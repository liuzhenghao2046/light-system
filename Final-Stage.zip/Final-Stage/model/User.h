/** 
 *  @file    MainApp.cpp
 *  @author  (zmaroofz) Zagros Maroofzadeh
 *  @date    28/11/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 final stage group project assignment1, holds information on the user
 */
#ifndef USER_H_
#define USER_H_

#include <Wt/Dbo/Types>
#include <Wt/WDate>
#include <Wt/Dbo/WtSqlTraits>
#include <Wt/WGlobal>
#include <Wt/Auth/Dbo/AuthInfo>
#include <vector>
#include "../Bridge.h"
namespace dbo = Wt::Dbo;
class User;
typedef Wt::Auth::Dbo::AuthInfo<User> AuthInfo;



class User {
public:
  dbo::weak_ptr<AuthInfo> authInfo;
  std::string firstName;///< first name of the user
  std::string lastName;///< last name of the user
  dbo::collection <dbo::ptr<Bridge>> bridges; ///< points to the bridges i the user
  template<class Action>
  /** 
  *   @brief  Persists the variables inside the database
  *   @return void
  */ 

  void persist(Action& a){
    dbo::field(a,firstName,"first_name");
    dbo::field(a,lastName,"last_name");
    dbo::hasOne(a, authInfo, "user");
    dbo::hasMany(a, bridges, dbo::ManyToOne, "user2");
      
  }
};


DBO_EXTERN_TEMPLATES(User);

#endif // USER_H_
