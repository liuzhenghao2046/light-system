#ifndef BRIDGE_H_
#define BRIDGE_H_

#include <Wt/Dbo/Types>
#include <Wt/WDate>
#include <Wt/Dbo/WtSqlTraits>
#include <Wt/WGlobal>
#include <Wt/Auth/Dbo/AuthInfo>
#include <vector>
#include "Group.h"
class User;
class Bridge;
namespace dbo = Wt::Dbo;
class Bridge{
	
	public:
		Bridge();
		Bridge(std::string name,std::string ip,std::string port,std::string location,std::string username);
		void setDetails(std::string name,std::string ip,std::string port,std::string location,std::string username);
		std::string getName();
		std::string getIp();
		std::string getPort();
		void setName(std::string name);
		std::string getlocation();
		std::string getUserName();
		dbo::ptr<User> user;
		dbo::collection <dbo::ptr<Group>> groups;
		template<class Action>

  /** 
  *   @brief  Persists the variables inside the database
  *   @return void
  */ 

  void persist(Action& a)
  {
    dbo::field(a,name_,"name");
    dbo::field(a,ip_,"ip");
    dbo::field(a,port_,"port");
    dbo::field(a,location_,"location");
        dbo::field(a,username_,"username");
         
         dbo::belongsTo(a, user, "user2");
    dbo::hasMany(a, groups, dbo::ManyToOne, "bridgeZ");
         
         
  }
	private:
		std::string name_; ///< store name of bridge
		std::string ip_;	///< store ip of bridge
		std::string port_;	///< sstore port of bridge
		std::string location_;	///< sstore location of bridge
		std::string username_;	///< sstore username of philip hues account - defaulted to newdeveloper
};
DBO_EXTERN_TEMPLATES(Bridge);
#endif



