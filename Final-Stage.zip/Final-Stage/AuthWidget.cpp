/** 
 *  @file    AuthWidget.cpp
 *  @author  (Group 17)
 *  @date    28/11/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 final stage group project assignment1, AuthWidget class. holds information on the auth settings
 */
#include "AuthWidget.h"
#include "RegistrationView.h"
#include "model/Session.h"

AuthWidget::AuthWidget(Session& session)
  : Wt::Auth::AuthWidget(Session::auth(), session.users(), session.login()),
    session_(session)
{  }


  /** 
  *   @brief  Creates the registration view
  *  
  *   @param  id	is a Wt::Auth::Identity type that holds an auth id
  *   @return void
  */ 

Wt::WWidget *AuthWidget::createRegistrationView(const Wt::Auth::Identity& id)
{
  RegistrationView *w = new RegistrationView(session_, this);
  Wt::Auth::RegistrationModel *model = createRegistrationModel();

  if (id.isValid()) // if id is valid
    model->registerIdentified(id);	 // register view pops up

  w->setModel(model);
  return w;
}
