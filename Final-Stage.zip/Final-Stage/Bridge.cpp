/** 
 *  @file    Bridge.cpp
 *  @author  (Group 17)
 *  @date    28/11/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 final stage group project assignment1, holds information on the bridge. Bridge is linked to user and also holds groups.
 */
#include <iostream>
#include "Bridge.h"
#include "model/User.h"
#include <string>
#include <Wt/Dbo/Impl>
#include <Wt/Auth/Dbo/AuthInfo>
using namespace std;
//constructor
  /** 
  *   @brief  Default bridge constructor
  */ 
Bridge::Bridge(){
}
  /** 
  *   @brief  Custom bridge constructor. automatically sets all fields to the inputted amounts
  *  
  *   @param  name an initialized string
  *   @param  ip an initialized string
  *   @param  port an initialized string
  *   @param  location an initialized string
  *   @param  username an initialized string
  *   @return void
  */ 
Bridge::Bridge(std::string name,std::string ip,std::string port,std::string location,std::string username){
	name_=name;
	ip_=ip;
	port_=port;
	location_=location;
	username_=username;
	if(username_==""){
		username_="newdeveloper";		
	}
}
  /** 
  *   @brief  Sets the name of a bridge
  *  
  *   @param  name an initialized string
  *   @return void
  */ 
void Bridge::setName(std::string name){
	name_=name;
}
  /** 
  *   @brief  Set all the bridge variables in one function
  *  
  *   @param  name an initialized string
  *   @param  ip an initialized string
  *   @param  port an initialized string
  *   @param  location an initialized string
  *   @param  username an initialized string
  *   @return void
  */ 
void Bridge::setDetails(std::string name,std::string ip,std::string port,std::string location,std::string username){
	name_=name;
	ip_=ip;
	port_=port;
	location_=location;
	username_=username;
	if(username_==""){
		username_="newdeveloper";		
	}
}
  /** 
  *   @brief  returns the name of a bridge
  *   @return void
  */ 
string Bridge::getName(){
	return name_;
}
  /** 
  *   @brief  returns the ip of a bridge
  *   @return void
  */ 
string Bridge::getIp(){
	return ip_;
}
  /** 
  *   @brief  returns the port of a bridge
  *   @return void
  */ 
string Bridge::getPort(){
	return port_;
}
  /** 
  *   @brief  returns the location of a bridge
  *   @return void
  */ 
string Bridge::getlocation(){
	return location_;
}
  /** 
  *   @brief  returns the username of a bridge
  *   @return void
  */ 
string Bridge::getUserName(){
	return username_;
}




DBO_INSTANTIATE_TEMPLATES(Bridge);
