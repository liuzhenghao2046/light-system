/** 
 *  @file    Group.cpp
 *  @author  Zagros Maroofzadeh (zmaroofz)
 *  @date    4/10/2017
 *  @version 1.0 
 *  
 *  @brief cs3307 assignment1, holds information on the address of a to-be generated person object
 */

#include <iostream>
#include <string>
#include <Wt/Dbo/Impl>
#include <Wt/Auth/Dbo/AuthInfo>

#include "Bridge.h"
#include "Group.h"
using namespace std;
  /** 
  *   @brief  Default constructor for Group
  */ 
Group::Group(){
}

  /** 
  *   @brief  Custom constructor for Group
  *   @param  Wt::WApplication is wt environment
  *   @return void
  */ 
Group::Group(std::string groupName,std::string lightList){
	lightList_=lightList;
	name_=groupName;
}
  /** 
  *   @brief  gets the name of a group
  *   @return string the name of the bridge
  */ 
std::string Group::getName(){
	return name_;
}

  /** 
  *   @brief  Get the list of lights inside a string that are in the Group
  *   @return string the list of lights stored in a string that are in the group
  */ 

std::string Group::getlightList(){
	return lightList_;
}
  /** 
  *   @brief  Sets the name of a group
  *   @return void
  */ 

void Group::setName(std::string name){
	name_=name;
}

  /** 
  *   @brief  Sets the light list string of a group
  *   @return void
  */ 
void Group::setList(std::string lightList){
	lightList_=lightList;
}


DBO_INSTANTIATE_TEMPLATES(Group);
