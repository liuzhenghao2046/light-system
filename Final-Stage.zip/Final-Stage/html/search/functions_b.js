var searchData=
[
  ['validate',['validate',['../classRegistrationView.html#abff4da7c898c36d81a8af6718840d27e',1,'RegistrationView']]]
];
