var searchData=
[
  ['persist',['persist',['../classBridge.html#a20b4d278bc879a5c647e106e03fa1cdc',1,'Bridge::persist()'],['../classGroup.html#afc2c9ae349b1d9d58b0d920fcf55bd82',1,'Group::persist()']]]
];
