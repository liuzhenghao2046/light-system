var searchData=
[
  ['bri_5f',['bri_',['../classHueApplication.html#ac48917bb28ea2f186abce82f75a00784',1,'HueApplication']]],
  ['bri_5f2',['bri_2',['../classHueApplication.html#a186fdf593d6fdacceecdd25ff0906713',1,'HueApplication']]],
  ['bridgeidselect_5f',['bridgeIDSelect_',['../classHueApplication.html#a148648a37fe8beaf1baf51be2fc4530b',1,'HueApplication']]],
  ['bridgesuccess',['bridgeSuccess',['../classHueApplication.html#ac8796145502abf4a61965a2b0502040c',1,'HueApplication']]]
];
