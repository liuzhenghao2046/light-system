var searchData=
[
  ['port_5f',['port_',['../classBridge.html#abbb2878a3b46eeb7546d8748226769f7',1,'Bridge']]],
  ['portedit_5f',['portEdit_',['../classHueApplication.html#a25bd7ceb709f7c46f5012feebbabb7dc',1,'HueApplication']]]
];
