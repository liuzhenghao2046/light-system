var searchData=
[
  ['authwidget_2ecpp',['AuthWidget.cpp',['../AuthWidget_8cpp.html',1,'']]]
];
