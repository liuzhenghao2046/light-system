var searchData=
[
  ['cur_5fbridge_5f',['cur_bridge_',['../classHueApplication.html#a17e18c04b29972b892be352c08193aa9',1,'HueApplication']]],
  ['cur_5fgroup_5f',['cur_group_',['../classHueApplication.html#a5da8accac0cfcab22d93b6e54d89a7f9',1,'HueApplication']]]
];
