var searchData=
[
  ['transitiontime_5f',['transitiontime_',['../classHueApplication.html#a4c0498c2d9e43638c4fc778ba00ebf63',1,'HueApplication']]],
  ['transitiontime_5f2',['transitiontime_2',['../classHueApplication.html#a768b637955b53d1c63be110ee5c58011',1,'HueApplication']]]
];
