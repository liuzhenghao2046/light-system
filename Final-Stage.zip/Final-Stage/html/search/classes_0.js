var searchData=
[
  ['authwidget',['AuthWidget',['../classAuthWidget.html',1,'']]]
];
