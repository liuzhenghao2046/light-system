#ifndef GROUP_H_
#define GROUP_H_

#include <Wt/Dbo/Types>
#include <Wt/WDate>
#include <Wt/Dbo/WtSqlTraits>
#include <Wt/WGlobal>
#include <Wt/Auth/Dbo/AuthInfo>
#include <vector>
class Bridge;
namespace dbo = Wt::Dbo;
class Group{
	
	public:
		Group();
		Group(std::string groupName,std::string lightList);
		void setName(std::string name);
		void setList(std::string lightList);
		std::string getName();
		std::string getlightList();
		dbo::ptr<Bridge> bridge;
		template<class Action>
  /** 
  *   @brief  Persists the variables inside the database
  *   @return void
  */ 

  void persist(Action& a)
  {
    dbo::field(a,name_,"name");
    dbo::field(a,lightList_,"lightList");
    dbo::belongsTo(a, bridge, "bridgeZ");
         
         
  }
	private:
		std::string name_;///< name of the group
		std::string lightList_;///< list of lights inside the group separated by commas. 
};
DBO_EXTERN_TEMPLATES(Group);
#endif



