var searchData=
[
  ['name_5f',['name_',['../classBridge.html#ad24059795d2ce28e73aa601dc3c91a90',1,'Bridge::name_()'],['../classGroup.html#a0561f88d0119b78935d6cfd84238878e',1,'Group::name_()']]],
  ['nameedit_5f',['nameEdit_',['../classHueApplication.html#a990f228252263d9614f703517205f82c',1,'HueApplication']]]
];
