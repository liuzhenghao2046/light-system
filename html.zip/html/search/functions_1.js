var searchData=
[
  ['bridge',['Bridge',['../classBridge.html#a275f54dafc95c9b5bbaba5e904c4fa9a',1,'Bridge::Bridge()'],['../classBridge.html#ad33ffa359c7097b194dd0c0d7e6d210f',1,'Bridge::Bridge(std::string name, std::string ip, std::string port, std::string location, std::string username)']]]
];
